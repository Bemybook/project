(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["src-welcome-welcome-module"],{

/***/ "ATN1":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/src/welcome/welcome.page.html ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n\n<ion-content>\n  <div  *ngIf='!recognize' style=\"background-color: #344955; color: #F9AA33; height: -webkit-fill-available;\">\n    <div *ngIf='welcome'>\n      <ion-row style=\"text-align: center;\">\n        <ion-col class=\"heading\">\n           BE MY BOOK\n        </ion-col>\n         \n       </ion-row>\n       <ion-row style=\"text-align: center;\">\n        <ion-col class=\"heading\" style=\"font-size: 1.5rem;\">\n          You hear what you choose to read\n        </ion-col>\n         \n       </ion-row>\n       <ion-row style=\"    margin-top: 25%;\">\n         <ion-col class='block'>\n          <img src=\"../../../assets/logo.gif\" style=\"height: 200px;\">\n         </ion-col>\n         \n       </ion-row>\n       <ion-row *ngIf=\"failed\" >\n         <ion-col class='rec' (click)='startReg()'>\n           Recognize Again\n         </ion-col>\n       </ion-row>\n       <!-- <ion-row *ngIf=\"!failed\" >\n        <ion-col class='rec1' >\n          <ion-icon name=\"checkmark-circle-outline\"></ion-icon>\n        </ion-col>\n      </ion-row> -->\n      <ion-row *ngIf=\"failed\" >\n        <ion-col class='rec2' >\n          <ion-icon name=\"alert-circle-outline\"></ion-icon>\n        </ion-col>\n      </ion-row>\n    </div>\n    <div *ngIf='!welcome'>\n      <ion-row style=\"text-align: center;\">\n        <ion-col class=\"heading\">\n          I’am Drushti. Your personal voice-assistant. You can call me ‘D’.\n\n        </ion-col>\n         \n       </ion-row>\n    </div>\n    \n  </div>\n  <div  *ngIf='recognize' style=\"color: #F9AA33; height: -webkit-fill-available;\">\n    <ion-row style=\"    margin-top: 25%;\">\n      <ion-col class='blocks'>\n       <img src=\"../../../assets/robot.gif\" style=\"height: 200px;\">\n      </ion-col>\n      \n    </ion-row>\n   \n\n    <ion-row>\n      <ion-col class='blockss'>\n        TELL YOUR NAME\n      </ion-col>\n    </ion-row>\n  </div>\n \n</ion-content>\n");

/***/ }),

/***/ "Eril":
/*!*******************************************************!*\
  !*** ./src/app/src/welcome/welcome-routing.module.ts ***!
  \*******************************************************/
/*! exports provided: WelcomePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WelcomePageRoutingModule", function() { return WelcomePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _welcome_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./welcome.page */ "bMeL");




const routes = [
    {
        path: '',
        component: _welcome_page__WEBPACK_IMPORTED_MODULE_3__["WelcomePage"]
    }
];
let WelcomePageRoutingModule = class WelcomePageRoutingModule {
};
WelcomePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], WelcomePageRoutingModule);



/***/ }),

/***/ "KCTE":
/*!***********************************************!*\
  !*** ./src/app/src/welcome/welcome.module.ts ***!
  \***********************************************/
/*! exports provided: WelcomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WelcomePageModule", function() { return WelcomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _welcome_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./welcome-routing.module */ "Eril");
/* harmony import */ var _welcome_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./welcome.page */ "bMeL");







let WelcomePageModule = class WelcomePageModule {
};
WelcomePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _welcome_routing_module__WEBPACK_IMPORTED_MODULE_5__["WelcomePageRoutingModule"]
        ],
        declarations: [_welcome_page__WEBPACK_IMPORTED_MODULE_6__["WelcomePage"]]
    })
], WelcomePageModule);



/***/ }),

/***/ "Nzh7":
/*!***********************************************!*\
  !*** ./src/app/src/welcome/welcome.page.scss ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".heading {\n  margin-top: 30%;\n  text-align: center;\n  font-size: 3rem;\n  font-weight: bolder;\n}\n\n.rec {\n  margin-top: 50px;\n  text-align: center;\n  font-size: xx-large;\n}\n\n.rec1 {\n  margin-top: 50px;\n  text-align: center;\n  font-size: 100px;\n  color: green;\n}\n\n.block {\n  margin: 20px;\n  color: black;\n  text-align: center;\n  font-size: 50px;\n  border: 10px solid #fdebcd;\n  border-radius: 20px;\n}\n\n.blocks {\n  margin: 20px;\n  color: black;\n  text-align: center;\n  font-size: 50px;\n}\n\n.blockss {\n  background-color: #344955;\n  margin: 20px;\n  color: #F9AA33;\n  text-align: center;\n  font-size: 2rem;\n}\n\n.rec2 {\n  margin-top: 50px;\n  text-align: center;\n  font-size: 100px;\n  color: red;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3dlbGNvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0csZUFBQTtFQUNDLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0FBQ0o7O0FBRUE7RUFDSSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUFDSjs7QUFHQTtFQUNJLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUVBLFlBQUE7QUFESjs7QUFLQTtFQUlJLFlBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsMEJBQUE7RUFDQSxtQkFBQTtBQUxKOztBQVFBO0VBSUksWUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUFSSjs7QUFhQTtFQUdJLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUFaSjs7QUFpQkE7RUFDSSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxVQUFBO0FBZEoiLCJmaWxlIjoid2VsY29tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGluZ3tcbiAgIG1hcmdpbi10b3A6IDMwJTtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC1zaXplOiAzcmVtO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkZXI7XG59XG5cbi5yZWN7XG4gICAgbWFyZ2luLXRvcDogNTBweDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC1zaXplOiB4eC1sYXJnZTtcbiAgICAvL2ZvbnQtd2VpZ2h0OiBib2xkZXI7XG59XG5cbi5yZWMxe1xuICAgIG1hcmdpbi10b3A6IDUwcHg7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGZvbnQtc2l6ZTogMTAwcHg7XG4gICAgXG4gICAgY29sb3I6IGdyZWVuO1xuICAgIC8vZm9udC13ZWlnaHQ6IGJvbGRlcjtcbn1cblxuLmJsb2Nre1xuICAgIC8vIGhlaWdodDogMTAwcHg7XG4gICAgLy8gd2lkdGg6IDgwJTtcbiAgICAvLyBiYWNrZ3JvdW5kLWNvbG9yOiAjZmRlYmNkO1xuICAgIG1hcmdpbjogMjBweDtcbiAgICBjb2xvcjogYmxhY2s7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGZvbnQtc2l6ZTogNTBweDtcbiAgICBib3JkZXI6IDEwcHggc29saWQgI2ZkZWJjZDtcbiAgICBib3JkZXItcmFkaXVzOiAyMHB4O1xufVxuXG4uYmxvY2tze1xuICAgIC8vIGhlaWdodDogMTAwcHg7XG4gICAgLy8gd2lkdGg6IDgwJTtcbiAgICAvLyBiYWNrZ3JvdW5kLWNvbG9yOiAjZmRlYmNkO1xuICAgIG1hcmdpbjogMjBweDtcbiAgICBjb2xvcjogYmxhY2s7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGZvbnQtc2l6ZTogNTBweDtcbiAgIC8vIGJvcmRlcjogMTBweCBzb2xpZCAjZmRlYmNkO1xuICAgLy8gYm9yZGVyLXJhZGl1czogMjBweDtcbn1cblxuLmJsb2Nrc3N7XG4gICAgLy8gaGVpZ2h0OiAxMDBweDtcbiAgICAvLyB3aWR0aDogODAlO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICMzNDQ5NTU7XG4gICAgbWFyZ2luOiAyMHB4O1xuICAgIGNvbG9yOiAjRjlBQTMzO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXNpemU6IDJyZW07XG4gICAvLyBib3JkZXI6IDEwcHggc29saWQgI2ZkZWJjZDtcbiAgIC8vIGJvcmRlci1yYWRpdXM6IDIwcHg7XG59XG5cbi5yZWMye1xuICAgIG1hcmdpbi10b3A6IDUwcHg7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGZvbnQtc2l6ZTogMTAwcHg7XG4gICAgY29sb3I6IHJlZDtcbiAgICAvL2ZvbnQtd2VpZ2h0OiBib2xkZXI7XG59Il19 */");

/***/ }),

/***/ "bMeL":
/*!*********************************************!*\
  !*** ./src/app/src/welcome/welcome.page.ts ***!
  \*********************************************/
/*! exports provided: WelcomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WelcomePage", function() { return WelcomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_welcome_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./welcome.page.html */ "ATN1");
/* harmony import */ var _welcome_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./welcome.page.scss */ "Nzh7");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_native_text_to_speech_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/text-to-speech/ngx */ "EvNN");
/* harmony import */ var _ionic_native_speech_recognition_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/speech-recognition/ngx */ "VGJl");







let WelcomePage = class WelcomePage {
    constructor(textToSpeech, platform, ngZone, navCtrl, speechRecognition) {
        this.textToSpeech = textToSpeech;
        this.platform = platform;
        this.ngZone = ngZone;
        this.navCtrl = navCtrl;
        this.speechRecognition = speechRecognition;
        this.failed = false;
        this.match = [];
        this.matched = false;
        this.names = ['sharath', 'swati', 'srikala', 'amogha'];
        this.matchedText = '';
        this.welcome = true;
        this.recognize = false;
        this.platform.ready().then(() => {
            this.simpleNote('Be My Book .');
            // this.empty('');
            setTimeout(() => {
                this.welcomeNote('YOU HEAR WHAT YOU CHOOSE TO READ');
            }, 2000);
            // 
        });
        //  this.welcomeNote('Welcome to Be My Book');
    }
    initiate() {
        setTimeout(() => {
            this.ngZone.run(() => {
                this.recognize = true;
            });
            //this.simpleNote('Hey I am Drushti.  I am your personal assistant. You can invoke me by saying Hey, D!');
            // this.initiate();
            this.usernameNote();
        }, 8000);
    }
    welcomeNote(text) {
        this.textToSpeech.speak({
            text: text,
            locale: 'en-IN',
            rate: 0.75
        })
            .then(() => {
            console.log('Done');
            // this.usernameNote();
            setTimeout(() => {
                this.ngZone.run(() => {
                    this.welcome = false;
                });
                this.simpleNote('Hey I am Drushti.  I am your personal assistant. You can invoke me by saying Hey, D!');
                this.initiate();
            }, 2000);
        })
            .catch((reason) => console.log(reason));
    }
    simpleNote(text) {
        this.textToSpeech.speak({
            text: text,
            locale: 'en-IN',
            rate: 0.75
        })
            .then(() => {
            console.log('Done');
            // this.usernameNote();
        })
            .catch((reason) => console.log(reason));
    }
    empty(text) {
        this.textToSpeech.speak({
            text: text,
            locale: 'en-IN',
            rate: 0.75
        })
            .then(() => {
            console.log('Done');
            // this.usernameNote();
        })
            .catch((reason) => console.log(reason));
    }
    exitNote() {
        let text = 'Welcome ' + this.matchedText + ', Access Granted';
        this.textToSpeech.speak({
            text: text,
            locale: 'en-IN',
            rate: 0.50
        })
            .then(() => {
            console.log('Done');
            // this.usernameNote();
            this.ngZone.run(() => {
                this.navCtrl.navigateForward('manual');
            });
        })
            .catch((reason) => console.log(reason));
    }
    usernameNote() {
        let text = ' TO LOGIN, PLEASE  ENTER YOUR NAME IN THE FORMAT  MY NAME IS YOUR NAME . FOR EXAMPLE MY NAME IS SWATI';
        this.textToSpeech.speak({
            text: text,
            locale: 'en-IN',
            rate: 0.50
        })
            .then(() => {
            console.log('Done');
            // this.usernameNote();
            this.recognizeSpeech();
        })
            .catch((reason) => console.log(reason));
    }
    recognizeSpeech() {
        this.speechRecognition.isRecognitionAvailable()
            .then((available) => {
            console.log(available);
            if (available) {
                this.initiateRecognize();
            }
            else {
                this.simpleNote('Speech Recognition is not available');
            }
        });
    }
    startReg() {
        this.speechRecognition.startListening()
            .subscribe((matches) => {
            console.log(matches);
            matches.forEach(element => {
                this.match.push(this.lastWord(element));
            });
            console.log(this.match);
            this.matched = false;
            for (let i = 0; i < this.names.length; i++) {
                for (let j = 0; j < this.match.length; j++) {
                    console.log(this.names[i]);
                    console.log(this.match[j]);
                    if (this.names[i].toLowerCase() === this.match[j].toLowerCase()) {
                        this.matched = true;
                        this.matchedText = this.match[j];
                    }
                }
            }
            if (this.matched) {
                this.exitNote();
            }
            else {
                this.ngZone.run(() => {
                    this.failed = true;
                });
                this.simpleNote('Access Denied');
            }
        }, (onerror) => console.log('error:', onerror));
    }
    initiateRecognize() {
        this.speechRecognition.hasPermission()
            .then((hasPermission) => {
            console.log(hasPermission);
            if (hasPermission) {
                this.startReg();
            }
            else {
                this.getPermission();
            }
        });
    }
    getPermission() {
        this.speechRecognition.requestPermission()
            .then(() => {
            console.log('Granted');
            this.startReg();
        }, () => console.log('Denied'));
    }
    ngOnInit() {
    }
    lastWord(words) {
        let n = words.replace(/[\[\]?.,\/#!$%\^&\*;:{}=\\|_~()]/g, "").split(" ");
        return n[n.length - 1];
    }
};
WelcomePage.ctorParameters = () => [
    { type: _ionic_native_text_to_speech_ngx__WEBPACK_IMPORTED_MODULE_5__["TextToSpeech"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["NgZone"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"] },
    { type: _ionic_native_speech_recognition_ngx__WEBPACK_IMPORTED_MODULE_6__["SpeechRecognition"] }
];
WelcomePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-welcome',
        template: _raw_loader_welcome_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_welcome_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], WelcomePage);



/***/ })

}]);
//# sourceMappingURL=src-welcome-welcome-module.js.map