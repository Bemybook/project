(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["manual-manual-module"],{

/***/ "3YyW":
/*!*************************************************!*\
  !*** ./src/app/manual/manual-routing.module.ts ***!
  \*************************************************/
/*! exports provided: ManualPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ManualPageRoutingModule", function() { return ManualPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _manual_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./manual.page */ "f0LX");




const routes = [
    {
        path: '',
        component: _manual_page__WEBPACK_IMPORTED_MODULE_3__["ManualPage"]
    }
];
let ManualPageRoutingModule = class ManualPageRoutingModule {
};
ManualPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ManualPageRoutingModule);



/***/ }),

/***/ "J/YO":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/manual/manual.page.html ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>manual</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n \n  <ion-list>\n    <ion-item-sliding *ngFor=\"let text of Text\">\n      <ion-item>\n        <ion-label text-wrap>{{text}}</ion-label>\n      </ion-item>\n     \n    </ion-item-sliding>\n  </ion-list>\n</ion-content>");

/***/ }),

/***/ "borl":
/*!*****************************************!*\
  !*** ./src/app/manual/manual.page.scss ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtYW51YWwucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "f0LX":
/*!***************************************!*\
  !*** ./src/app/manual/manual.page.ts ***!
  \***************************************/
/*! exports provided: ManualPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ManualPage", function() { return ManualPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_manual_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./manual.page.html */ "J/YO");
/* harmony import */ var _manual_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./manual.page.scss */ "borl");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_native_text_to_speech_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/text-to-speech/ngx */ "EvNN");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");






let ManualPage = class ManualPage {
    constructor(textToSpeech, ngZone, platform, navCtrl, actionSheetController) {
        this.textToSpeech = textToSpeech;
        this.ngZone = ngZone;
        this.platform = platform;
        this.navCtrl = navCtrl;
        this.actionSheetController = actionSheetController;
        this.Text = [];
        this.platform.ready().then(() => {
            this.Text = [
                "START - This command is used to Start reading from the beginning of the book.",
                "STOP - This command will stop reading the book.",
                "PAUSE - To temporarily stop reading. ",
                "Resume- To continue from where it was paused.",
                "GOTO - To goto a particular page.  Eg: goto “pg number”.",
                "OPEN- To open a particular book or manual. Eg: open manual.",
                "SAVE_AS - To save the book with particular name. Eg: save_as book 1.",
                "FIND: To find a particular word in the book. Eg: find word.",
                "SEARCH : To search for a book online. Eg: search book.",
                "READ_FAST/ READ_SLOW - To increase or decrease the speed of reading.",
                "CHANGE_VOICE- To change from female to male voice and vice-versa."
            ];
            this.simpleNote("START - This command is used to Start reading from the beginning of the book. STOP - This command will stop reading the book." +
                "PAUSE - To temporarily stop reading. " +
                "Resume- To continue from where it was paused." +
                "GOTO - To goto a particular page.  example: goto “page number”." +
                "OPEN- To open a particular book or manual. example: open manual." +
                "SAVE_AS - To save the book with particular name. example: save_as book 1." +
                "FIND - To find a particular word in the book. example: find word." +
                "SEARCH - To search for a book online. example: search book." +
                "READ FAST or READ SLOW - To increase or decrease the speed of reading." +
                "CHANGE_VOICE- To change from female to male voice and vice-versa.");
        });
    }
    simpleNote(text) {
        this.textToSpeech.speak({
            text: text,
            locale: 'en-IN',
            rate: 0.75
        })
            .then(() => {
            console.log('Done');
            // this.usernameNote();
            this.ngZone.run(() => {
                this.navCtrl.navigateRoot('home');
            });
        })
            .catch((reason) => console.log(reason));
    }
    ngOnInit() {
    }
};
ManualPage.ctorParameters = () => [
    { type: _ionic_native_text_to_speech_ngx__WEBPACK_IMPORTED_MODULE_4__["TextToSpeech"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["NgZone"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["Platform"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ActionSheetController"] }
];
ManualPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-manual',
        template: _raw_loader_manual_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_manual_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ManualPage);



/***/ }),

/***/ "pSiy":
/*!*****************************************!*\
  !*** ./src/app/manual/manual.module.ts ***!
  \*****************************************/
/*! exports provided: ManualPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ManualPageModule", function() { return ManualPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _manual_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./manual-routing.module */ "3YyW");
/* harmony import */ var _manual_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./manual.page */ "f0LX");







let ManualPageModule = class ManualPageModule {
};
ManualPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _manual_routing_module__WEBPACK_IMPORTED_MODULE_5__["ManualPageRoutingModule"]
        ],
        declarations: [_manual_page__WEBPACK_IMPORTED_MODULE_6__["ManualPage"]]
    })
], ManualPageModule);



/***/ })

}]);
//# sourceMappingURL=manual-manual-module.js.map