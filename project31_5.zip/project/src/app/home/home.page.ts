import { Camera, CameraOptions } from '@ionic-native/camera/ngx';
import { Component } from '@angular/core';
import { TextToSpeech } from '@ionic-native/text-to-speech/ngx';
import { OCR, OCRSourceType, OCRResult } from '@ionic-native/ocr/ngx';
import { Platform, ActionSheetController, NavController } from '@ionic/angular';


@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})

export class HomePage {

  Text = [];

  constructor(
    private textToSpeech: TextToSpeech,
    private ocr: OCR,
    public platform: Platform,
    public camera: Camera,
    public navCtrl: NavController,
    public actionSheetController: ActionSheetController,
  ) {
    this.platform.ready().then(() => {
      this.Text = [
        "this is sample",

      ];

      // (OCRSourceType.NORMFILEURL, "file:///Download/Test.jpeg")
    //   let src = '';
    //   this.ocr.recText(OCRSourceType.BASE64, src)
    //     .then((res: OCRResult) => {
    //       console.log(res);
    //       try {
    //         if (res.foundText) {
    //           res.blocks.blocktext.forEach(element => {
    //             this.Text.push(element);
    //           });
    //         }
    //       } catch (e) {

    //       }

    //     })
    //     .catch((error: any) => console.log(JSON.stringify(error)));
     })

  }

  logout(){
    this.navCtrl.navigateRoot('welcome');
  }



  takePicture(sourceType) {
    console.log('take Picture');
    this.Text = [];
    const options: CameraOptions = {
      quality: 100,
      sourceType: sourceType,
      destinationType: this.camera.DestinationType.DATA_URL,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE

    }

    this.camera.getPicture(options).then((imageData) => {
      // imageData is either a base64 encoded string or a file URI
      // If it's base64 (DATA_URL):
      let base64Image = 'data:image/jpeg;base64,' + imageData;
      console.log(base64Image);
      let src = imageData;
      this.ocr.recText(OCRSourceType.BASE64, src)
        .then((res: OCRResult) => {
          console.log(res);
          try {
            if (res.foundText) {
              res.blocks.blocktext.forEach(element => {
                this.Text.push(element);
              });
            }
            else{
              this.Text.push('No Text Found');
            }
          } catch (e) {

          }

        })
        .catch((error: any) => console.log(JSON.stringify(error)));
    
  }, (err) => {
    // Handle error
  });
  }






// convertTextToSpeech(text) {
//   this.textToSpeech.speak(text)
//     .then(
//       () => console.log('Done')
//     )
//     .catch((reason: any) => console.log(reason));
// }

convertTextToSpeech(text) {
  this.textToSpeech.speak({
    text: text,
    locale: 'en-GB',
    rate: 0.75
  })
    .then(() =>
      console.log('Done')
    )
    .catch((reason: any) =>
      console.log(reason)
    );
}

async selectImage() {
  const actionSheet = await this.actionSheetController.create({
    header: "Select Image source",
    buttons: [{
      text: 'Load from Library',
      handler: () => {
        this.takePicture(this.camera.PictureSourceType.PHOTOLIBRARY);
      }
    },
    {
      text: 'Use Camera',
      handler: () => {
        this.takePicture(this.camera.PictureSourceType.CAMERA);
      }
    },
    {
      text: 'Cancel',
      role: 'cancel'
    }
    ]
  });
  await actionSheet.present();
}

}