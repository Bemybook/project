import { Component, OnInit, NgZone } from '@angular/core';
import { TextToSpeech } from '@ionic-native/text-to-speech/ngx';
import { Platform, NavController, ActionSheetController } from '@ionic/angular';

@Component({
  selector: 'app-manual',
  templateUrl: './manual.page.html',
  styleUrls: ['./manual.page.scss'],
})
export class ManualPage implements OnInit {

  Text: any = [];
  constructor(
    private textToSpeech: TextToSpeech,
    public ngZone: NgZone,
    public platform: Platform,
   
    public navCtrl: NavController,
    public actionSheetController: ActionSheetController,
  ) { 
    this.platform.ready().then(() => {
      this.Text = [
        "START - This command is used to Start reading from the beginning of the book.",
        "STOP - This command will stop reading the book.",
        "PAUSE - To temporarily stop reading. ",
        "Resume- To continue from where it was paused.",
        "GOTO - To goto a particular page.  Eg: goto “pg number”.",
        "OPEN- To open a particular book or manual. Eg: open manual.",
        "SAVE_AS - To save the book with particular name. Eg: save_as book 1.",
        "FIND: To find a particular word in the book. Eg: find word.",
        "SEARCH : To search for a book online. Eg: search book.",
        "READ_FAST/ READ_SLOW - To increase or decrease the speed of reading.",
        "CHANGE_VOICE- To change from female to male voice and vice-versa."

      ];
      this.simpleNote("START - This command is used to Start reading from the beginning of the book. STOP - This command will stop reading the book."+
      "PAUSE - To temporarily stop reading. "+
      "Resume- To continue from where it was paused."+
      "GOTO - To goto a particular page.  example: goto “page number”."+
      "OPEN- To open a particular book or manual. example: open manual."+
      "SAVE_AS - To save the book with particular name. example: save_as book 1."+
      "FIND - To find a particular word in the book. example: find word."+
      "SEARCH - To search for a book online. example: search book."+
      "READ FAST or READ SLOW - To increase or decrease the speed of reading."+
      "CHANGE_VOICE- To change from female to male voice and vice-versa.");
    
     })

  }

  simpleNote(text){
    this.textToSpeech.speak({
      text: text,
      locale: 'en-IN',
      rate: 0.75
    })
      .then(() =>{
        console.log('Done');
       // this.usernameNote();
       this.ngZone.run(() => {
        this.navCtrl.navigateRoot('home');

      });

      }
        

      )
      .catch((reason: any) =>
        console.log(reason)
      );
  }
  

  ngOnInit() {
  }

}
