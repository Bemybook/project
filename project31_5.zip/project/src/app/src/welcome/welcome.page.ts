import { Platform, NavController } from '@ionic/angular';
import { Component, OnInit, NgZone } from '@angular/core';
import { TextToSpeech } from '@ionic-native/text-to-speech/ngx';
import { SpeechRecognition } from '@ionic-native/speech-recognition/ngx';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.page.html',
  styleUrls: ['./welcome.page.scss'],
})
export class WelcomePage implements OnInit {

  failed = false;
  match: any = [];
  matched = false;
  names: any = ['sharath', 'swati', 'srikala', 'amogha'];
  matchedText: any = '';
  welcome = true;
  recognize = false;

  constructor(public textToSpeech: TextToSpeech,
    public platform: Platform,
    public ngZone: NgZone,
    public navCtrl: NavController,
    public speechRecognition: SpeechRecognition) {
    this.platform.ready().then(() => {
      this.simpleNote('Be My Book .');
      // this.empty('');
      setTimeout(() => {
        this.welcomeNote('YOU HEAR WHAT YOU CHOOSE TO READ');
      }, 2000);
      // 
    });
    //  this.welcomeNote('Welcome to Be My Book');
  }

  initiate() {
    setTimeout(() => {
      this.ngZone.run(() => {
        this.recognize = true;
      });
      //this.simpleNote('Hey I am Drushti.  I am your personal assistant. You can invoke me by saying Hey, D!');
      // this.initiate();
      this.usernameNote();
    }, 8000);

  }

  welcomeNote(text) {

    this.textToSpeech.speak({
      text: text,
      locale: 'en-IN',
      rate: 0.75
    })
      .then(() => {
        console.log('Done');
        // this.usernameNote();
        setTimeout(() => {
          this.ngZone.run(() => {
            this.welcome = false;
          });
          this.simpleNote('Hey I am Drushti.  I am your personal assistant. You can invoke me by saying Hey, D!');
          this.initiate();
        }, 2000);




      }


      )
      .catch((reason: any) =>
        console.log(reason)
      );

  }
  simpleNote(text) {
    this.textToSpeech.speak({
      text: text,
      locale: 'en-IN',
      rate: 0.75
    })
      .then(() => {
        console.log('Done');
        // this.usernameNote();
      }


      )
      .catch((reason: any) =>
        console.log(reason)
      );
  }

  empty(text) {
    this.textToSpeech.speak({
      text: text,
      locale: 'en-IN',
      rate: 0.75
    })
      .then(() => {
        console.log('Done');
        // this.usernameNote();
      }


      )
      .catch((reason: any) =>
        console.log(reason)
      );
  }

  exitNote() {
    let text = 'Welcome ' + this.matchedText + ', Access Granted';
    this.textToSpeech.speak({
      text: text,
      locale: 'en-IN',
      rate: 0.50
    })
      .then(() => {
        console.log('Done');
        // this.usernameNote();
        this.ngZone.run(() => {
          this.navCtrl.navigateForward('manual');

        });
      }


      )
      .catch((reason: any) =>
        console.log(reason)
      );
  }

  usernameNote() {
    let text = ' TO LOGIN, PLEASE  ENTER YOUR NAME IN THE FORMAT  MY NAME IS YOUR NAME . FOR EXAMPLE MY NAME IS SWATI';
    this.textToSpeech.speak({
      text: text,
      locale: 'en-IN',
      rate: 0.50
    })
      .then(() => {
        console.log('Done');
        // this.usernameNote();
        this.recognizeSpeech();
      }


      )
      .catch((reason: any) =>
        console.log(reason)
      );
  }

  recognizeSpeech() {
    this.speechRecognition.isRecognitionAvailable()
      .then((available: boolean) => {
        console.log(available);
        if (available) {
          this.initiateRecognize();
        } else {
          this.simpleNote('Speech Recognition is not available');
        }
      }
      )
  }

  startReg() {
    this.speechRecognition.startListening()
      .subscribe(
        (matches: string[]) => {
          console.log(matches);
          matches.forEach(element => {
            this.match.push(this.lastWord(element));
          });
          console.log(this.match);
          this.matched = false;

          for (let i = 0; i < this.names.length; i++) {
            for (let j = 0; j < this.match.length; j++) {
              console.log(this.names[i]);
              console.log(this.match[j]);
              if (this.names[i].toLowerCase() === this.match[j].toLowerCase()) {
                this.matched = true;
                this.matchedText = this.match[j];
              }
            }
          }

          if (this.matched) {
            this.exitNote();
          } else {
            this.ngZone.run(() => {

              this.failed = true;

            });

            this.simpleNote('Access Denied')
          }



        },
        (onerror) => console.log('error:', onerror)
      )
  }

  initiateRecognize() {
    this.speechRecognition.hasPermission()
      .then((hasPermission: boolean) => {
        console.log(hasPermission);
        if (hasPermission) {
          this.startReg();
        } else {
          this.getPermission();
        }

      }
      )


  }

  getPermission() {
    this.speechRecognition.requestPermission()
      .then(
        () => {
          console.log('Granted');
          this.startReg();
        },
        () => console.log('Denied')
      )
  }

  ngOnInit() {

  }

  lastWord(words) {
    let n = words.replace(/[\[\]?.,\/#!$%\^&\*;:{}=\\|_~()]/g, "").split(" ");
    return n[n.length - 1];
  }

}
