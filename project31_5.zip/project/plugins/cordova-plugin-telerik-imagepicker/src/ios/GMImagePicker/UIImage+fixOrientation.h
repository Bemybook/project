@interface UIImage(fixOrientation)

- (UIImage *)fixOrientation;

@end